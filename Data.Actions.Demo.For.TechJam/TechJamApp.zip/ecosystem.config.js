"use strict";
var maxHeapSize = process.env.NODE_PM2_MEM_RELOAD_LIMIT ? parseInt(`${process.env.NODE_PM2_MEM_RELOAD_LIMIT}`) : 750;
// Add 200 MB to the max heap size over the reload limit
maxHeapSize += 200;
module.exports = {
    apps: [
        {
            name: 'rushmore',
            script: 'build/server.js',
            kill_timeout: process.env.NODE_PM2_KILL_TIMEOUT || 15000,
            instances: process.env.NODE_PM2_INSTANCE_COUNT || 0,
            max_memory_restart: process.env.NODE_PM2_MEM_RELOAD_LIMIT || '750M',
            exec_mode: 'cluster',
            node_args: ['--max-http-header-size=65536', `--max_old_space_size=${maxHeapSize}`],
            env: {
                NODE_ENV: 'development'
            },
            env_production: {
                NODE_ENV: 'production'
            }
        }
    ]
};
